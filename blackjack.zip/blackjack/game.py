from blackjack.deck import Deck
from blackjack.hand import Hand


class Game:
    def __init__(self):
        self.deck = Deck()
        self.dealer_hand = Hand("Dealer")
        self.player_hand = Hand("Player")
        self.game_over = False

    @property
    def sum_for_player(self):
        return sum(v.value for v in self.player_hand.cards)

    @property
    def sum_for_dealer(self):
        return sum(v.value for v in self.dealer_hand.cards)

    def start_game(self):
        player_card1 = self.deck.draw_a_card()
        dealer_card1 = self.deck.draw_a_card()
        player_card2 = self.deck.draw_a_card()
        dealer_card2 = self.deck.draw_a_card()

        self.player_hand.add_card(player_card1)
        self.player_hand.add_card(player_card2)
        self.dealer_hand.add_card(dealer_card1)
        self.dealer_hand.add_card(dealer_card2)

    def check_for_win(self, value):
        if value == 21:
            self.game_over = True
            return "won"
        elif value > 21:
            self.game_over = True
            return "Busted"
        elif value < 21:
            return False

    def show_hands(self):
        print(f"Player's hand: {', '.join(str(card) for card in self.player_hand.cards)}")
        print(f"Player's hand value: {self.sum_for_player}")
        print(f"Dealer's hand: {', '.join(str(card) for card in self.dealer_hand.cards)}")
        print(f"Dealer's hand value: {self.sum_for_dealer}")

    def hit(self):
        new_card = self.deck.draw_a_card()
        self.player_hand.add_card(new_card)
        self.show_hands()
        result = self.check_for_win(self.sum_for_player)
        if result:
            print("Player", result)

    def stand(self):
        while self.sum_for_dealer < 17:
            new_card = self.deck.draw_a_card()
            self.dealer_hand.add_card(new_card)

        self.show_hands()

        player_score = self.sum_for_player
        dealer_score = self.sum_for_dealer

        if dealer_score > 21:
            print("Dealer Busted. Player wins!")
        elif dealer_score == 21:
            print("Dealer has Blackjack. Player loses!")
        elif dealer_score > player_score:
            print("Dealer wins!")
        elif dealer_score < player_score:
            print("Player wins!")
        else:
            print("It's a tie!")

    def choose(self):
        while not self.game_over:
            self.show_hands()
            choice = input("Please choose Hit or Stand: ").lower().strip()
            if choice == "hit":
                self.hit()
            elif choice == "stand":
                self.stand()
                self.game_over = True


# Create a game instance and start playing
if __name__ == "__main__":
    game = Game()
    game.start_game()
    game.choose()