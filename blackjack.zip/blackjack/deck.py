from blackjack.card import Card

from random import shuffle


class Deck:
    SUITS = ("clubs", "diamonds", "hearts", "spades")
    FACES = {
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
        "ten": 10,
        "jack": 10,
        "queen": 10,
        "king": 10,
        "ace": 1
    }

    def __init__(self):
        self.cards = [Card(face, suit, value) for suit in Deck.SUITS for face, value in Deck.FACES.items()]
        shuffle(self.cards)

    def draw_a_card(self):
        drawn = self.cards.pop()

        return drawn
