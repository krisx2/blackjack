class Card:
    def __init__(self, face: str, suit: str, value: int):
        self.value = value
        self.suit = suit
        self.face = face

    def __repr__(self):
        return f"{self.face} of {self.suit}"
