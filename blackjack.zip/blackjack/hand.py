from typing import List

from blackjack.card import Card


class Hand:
    def __init__(self, name: str):
        self.name = name
        self.cards: List[Card] = []

    def add_card(self, card: Card):
        self.cards.append(card)


